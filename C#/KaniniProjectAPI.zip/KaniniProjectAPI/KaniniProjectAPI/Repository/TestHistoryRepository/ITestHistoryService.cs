﻿using KaniniProjectAPI.Repository.TestHistoryRepository;
using Microsoft.AspNetCore.Mvc;

namespace KaniniProjectAPI.Repository.TestHistoryRepository
{
    public interface ITestHistoryService
    {
        public Task<TestHistoryDTO> GetHistory();
    }
}
