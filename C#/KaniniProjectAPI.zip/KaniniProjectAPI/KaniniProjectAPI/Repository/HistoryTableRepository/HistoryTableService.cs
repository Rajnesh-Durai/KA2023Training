﻿using KaniniProjectAPI.Data;
using KaniniProjectAPI.Repository.HistoryTableRepository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SkillAssessmentAdmin.Models;

namespace KaniniProjectAPI.Repository.HistoryTableRepository
{/*
    public class HistoryTableService:IHistoryTableService
    {
        private readonly SkillAssessmentDbContext _skillAssessmentDbContext;
        public HistoryTableService(SkillAssessmentDbContext skillAssessmentDbContext)
        {
            _skillAssessmentDbContext = skillAssessmentDbContext;
        }
        public async Task<List<JobSeekerHistoryDTO>> GetJobSeekerHistory()
        {
            var item= await (from a in _skillAssessmentDbContext.Assessments
                             join u in _skillAssessmentDbContext.Users on a.UserId equals u.Id
                             join d in _skillAssessmentDbContext.Departments on a.DepartmentId equals d.Id
                             join s in _skillAssessmentDbContext.Skills on a.SkillId equals s.Id
                             where u.Roles=="JobSeeker"
                             select new JobSeekerHistoryDTO()
                             {
                                 AssessmentId= a.Id,
                                 Department=d.DepartmentName,
                                 Skill=s.SkillLevel,
                                 UserEmail=u.Email,
                                 NumberOfTopics=a.NumberOfTopics,
                                 DateOfCompletion=a.DateOfCompletion,
                                 Status=a.Status
                             }).ToListAsync();
            return item;
        }
        public async Task<List<EmployeeHistoryDTO>> GetEmployeeHistory()
        {
            var item = await (from a in _skillAssessmentDbContext.Assessments
                              join u in _skillAssessmentDbContext.Users on a.UserId equals u.Id
                              join d in _skillAssessmentDbContext.Departments on a.DepartmentId equals d.Id
                              join s in _skillAssessmentDbContext.Skills on a.SkillId equals s.Id
                              where u.Roles == "Employee"
                              select new EmployeeHistoryDTO()
                              {
                                  AssessmentId = a.Id,
                                  EmpId = u.Id,
                                  Photo=u.UserImage,
                                  Name = u.FirstName + " " + u.LastName,
                                  Department = d.DepartmentName,
                                  Skill = s.SkillLevel,
                                  UserEmail = u.Email,
                                  NumberOfTopics = a.NumberOfTopics,
                                  DateOfCompletion = a.DateOfCompletion,
                                  Status = a.Status
                              }).ToListAsync();
            return item;
        }
        public async Task<ActionResult<List<RequestHistoryDTO>>> GetRequestHistory()
        {
            var item = await (from a in _skillAssessmentDbContext.Assessments
                              join u in _skillAssessmentDbContext.Users on a.UserId equals u.Id
                              join d in _skillAssessmentDbContext.Departments on a.DepartmentId equals d.Id
                              join s in _skillAssessmentDbContext.Skills on a.SkillId equals s.Id
                              where u.Roles == "Employee"
                              select new RequestHistoryDTO()
                              {
                                  AssessmentId = a.Id,
                                  EmpId = u.Id,
                                  Photo = u.UserImage,
                                  Name = u.FirstName + " " + u.LastName,
                                  Department = d.DepartmentName,
                                  Skill = s.SkillLevel,
                                  NumberOfTopics = a.NumberOfTopics,
                                  DateOfRequest = a.DateOfCompletion
                              }).ToListAsync();
            return item;
        }
    }*/
}
