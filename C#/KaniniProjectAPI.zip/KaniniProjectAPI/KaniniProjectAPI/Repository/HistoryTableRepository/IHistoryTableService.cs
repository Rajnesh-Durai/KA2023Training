﻿using Microsoft.AspNetCore.Mvc;
using SkillAssessmentAdmin.Models;

namespace KaniniProjectAPI.Repository.HistoryTableRepository
{
    public interface IHistoryTableService
    {
/*        public Task<List<JobSeekerHistoryDTO>> GetJobSeekerHistory();
        public Task<List<EmployeeHistoryDTO>> GetEmployeeHistory();
        public Task<List<RequestHistoryDTO>> GetRequestHistory();*/
    }
}
