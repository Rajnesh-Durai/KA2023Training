﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;

namespace KaniniProjectAPI.Repository.HistoryTableRepository
{
    public class JobSeekerHistoryDTO
    {
        public string AssessmentId { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Skill { get; set; } = string.Empty;
        public string UserEmail { get; set; }
        public int NumberOfTopics { get; set; }
        [Column(TypeName = "Date")]
        public DateTime DateOfCompletion { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}
