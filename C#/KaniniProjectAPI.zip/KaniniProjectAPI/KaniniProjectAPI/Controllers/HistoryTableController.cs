﻿using KaniniProjectAPI.Repository.HistoryTableRepository;
using Microsoft.AspNetCore.Mvc;
using SkillAssessmentAdmin.Models;

namespace KaniniProjectAPI.Controllers
{
    [Route("HistoryTable")]
    [ApiController]
    public class HistoryTableController:ControllerBase
    {
/*        private readonly IHistoryTableService _historyTableService;
        public HistoryTableController(IHistoryTableService historyTableService)
        {
            _historyTableService = historyTableService;
        }
        [HttpGet("JobSeekerHistory")]
        public async Task<ActionResult<List<JobSeekerHistoryDTO>>> GetJobSeekerHistory()
        {
           var item= await _historyTableService.GetJobSeekerHistory();
            return Ok(item);
        }
        [HttpGet("EmployeeHistory")]
        public async Task<ActionResult<List<EmployeeHistoryDTO>>> GetEmployeeHistory()
        {
            var item = await _historyTableService.GetEmployeeHistory();
            return Ok(item);
        }
        [HttpGet("RequestHistory")]
        public async Task<ActionResult<List<RequestHistoryDTO>>> GetRequestHistory()
        {
            var item = await _historyTableService.GetRequestHistory();
            return Ok(item);
        }*/
    }
}
