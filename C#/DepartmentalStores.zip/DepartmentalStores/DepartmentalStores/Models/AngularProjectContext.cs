﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DepartmentalStores.Models;

public partial class AngularProjectContext : DbContext
{
    public AngularProjectContext()
    {
    }

    public AngularProjectContext(DbContextOptions<AngularProjectContext> options)
        : base(options)
    {
    }

    public virtual DbSet<ProductsUpdated> ProductsUpdateds { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }
/*#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source = .\\SQLEXPRESS; initial catalog = AngularProject; integrated security=SSPI;TrustServerCertificate=True;");
*/
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ProductsUpdated>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("PK__Products__B40CC6CD198B28F0");

            entity.ToTable("ProductsUpdated");

            entity.Property(e => e.AvailableQuantity).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.Price).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.Product).HasMaxLength(30);
            entity.Property(e => e.ProductSection).HasMaxLength(30);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
