﻿using DepartmentalStores.Models;
using Microsoft.AspNetCore.Mvc;

namespace DepartmentalStores.Repository.ProductService
{
    public interface IProductServices
    {
        Task<List<ProductsUpdated>> DisplayAllProducts();

        public Task<List<ProductsUpdated>> DisplayFruitSection();
        public Task<List<ProductsUpdated>> DisplayVegSection();
        public Task<List<ProductsUpdated>> DisplayGrocerySection();
        public Task<List<ProductsUpdated>> DisplayStatSection();

        Task<ProductsUpdated> GetById(int id);

        Task<List<ProductsUpdated>> PostProductsUpdated(ProductsUpdated productsUpdated);
        Task<List<ProductsUpdated>> PutProductsUpdated(int id, ProductsUpdated productsUpdated);
        Task<List<ProductsUpdated>> DeleteValues(int id);
    }
}
