﻿using DepartmentalStores.Authentication;
using System.Security.Claims;

namespace DepartmentalStores.Repository.Token
{
    public interface ITokenService
    {
        TokenResponse GetToken(IEnumerable<Claim> claim);
        string GetRefreshToken();
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
