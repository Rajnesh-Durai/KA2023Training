﻿using Microsoft.AspNetCore.Identity;

namespace DepartmentalStores.Authentication
{
    public class ApplicationUser : IdentityUser
    {
        public string? Name { get; set; }
    }
}
