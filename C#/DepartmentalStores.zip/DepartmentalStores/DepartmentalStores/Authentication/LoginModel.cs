﻿using System.ComponentModel.DataAnnotations;

namespace DepartmentalStores.Authentication
{
    public class LoginModel
    {
        [Required]
        public string? Username { get; set; }

        [Required]
        public string? Password { get; set; }
    }
}
