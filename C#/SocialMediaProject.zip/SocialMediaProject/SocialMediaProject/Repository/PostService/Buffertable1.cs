﻿namespace SocialMediaProject.Repository.PostService
{
    public class Buffertable1
    {
        public int Id { get; set; }
        public string Name { get; set; }
            
        public string Description { get; set; }
        public string Type { get; set; }
        public string Type2 { get; set; }
        = string.Empty;
    }
}
