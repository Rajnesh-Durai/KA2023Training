﻿namespace SocialMediaProject.Auth
{
    public class Responses
    {
        public string? Status { get; set; }
        public string? StatusMessage { get; set; }
    }
}
