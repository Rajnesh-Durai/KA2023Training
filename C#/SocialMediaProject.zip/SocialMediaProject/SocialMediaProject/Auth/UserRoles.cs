﻿namespace SocialMediaProject.Auth
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "user";
    }
}
